from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

app = Flask(__name__)

# Load the trained model (from joblib)
model = joblib.load(r"D:\cafeteria\model.pkl")

# Read CSV to get column names and possible validation (if necessary)
df = pd.read_csv(r'D:\cafeteria\cafeteria_orders_with_delivery_time.csv')
df["Order Time"] = pd.to_datetime(df["Order Time"], errors="coerce")
df["Order Hour"] = df["Order Time"].dt.hour

# Handle conversion for the features used in prediction
df["Order Time"] = pd.to_datetime(df["Order Time"], errors="coerce").apply(lambda x: x.hour * 60 + x.minute)
df["Delivery Time"] = pd.to_datetime(df["Delivery Time"], format="%H:%M:%S", errors="coerce") \
                      .apply(lambda x: x.hour * 60 + x.minute if pd.notnull(x) else np.nan)

# Select relevant features
features = ["Order Time", "Preparation Time (mins)", "Token Number", "Quantity"]

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/predict', methods=["POST"])
def predict():
    try:
        # Get the form inputs
        order_time = request.form["order_time"]
        preparation_time = request.form["preparation_time"]
        token_number = request.form["token_number"]
        quantity = request.form["quantity"]
        
        # Convert the order time into minutes
        order_time_minutes = pd.to_datetime(order_time, errors="coerce").hour * 60 + pd.to_datetime(order_time, errors="coerce").minute
        
        # Prepare the feature array for prediction
        features_input = np.array([[order_time_minutes, preparation_time, token_number, quantity]])
        
        # Predict using the model
        prediction = model.predict(features_input)
        
        # Convert the predicted minutes into hours and minutes (H:M:00 format)
        predicted_time = convert_to_hms(prediction[0])

        return render_template("index.html", prediction=predicted_time)
    except Exception as e:
        return f"An error occurred: {e}"

def convert_to_hms(minutes):
    if np.isnan(minutes):  # Handle NaN values
        return "NaN"
    hours = int(minutes // 60)
    mins = int(minutes % 60)
    return f"{hours:02}:{mins:02}:00"

if __name__ == "__main__":
    app.run(debug=True)
