import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error

df = pd.read_csv('cafeteria_orders_with_delivery_time.csv')

df.head()



df["Order Time"] = pd.to_datetime(df["Order Time"], errors="coerce")

# Extract the hour from 'Order Time'
df["Order Hour"] = df["Order Time"].dt.hour

# Group by hour and count orders
hourly_order_counts = df.groupby("Order Hour")["Order ID"].count()

# Find the peak order hour
if not hourly_order_counts.empty:
    max_order_hour = hourly_order_counts.idxmax()
    max_order_count = hourly_order_counts.max()
    print(f"The hour with the maximum orders is {max_order_hour}:00 with {max_order_count} orders.")

    df.loc[df["Order Hour"] == max_order_hour, "Delivery Time"] += pd.Timedelta(minutes=20)
else:
    print("No orders found in the dataset.")

# Plot hourly order counts
plt.figure(figsize=(8,5))
sns.barplot(x=hourly_order_counts.index, y=hourly_order_counts.values, palette="coolwarm")
plt.xlabel("Hour")
plt.ylabel("Number of Orders")
plt.title("Hourly Order Counts")
plt.xticks(range(0, 24))
plt.show()



# Convert 'Order Time' and 'Delivery Time' to total minutes from midnight
df["Order Time"] = pd.to_datetime(df["Order Time"], errors="coerce").apply(lambda x: x.hour * 60 + x.minute)
#df["Delivery Time"] = pd.to_datetime(df["Delivery Time"], errors="coerce").apply(lambda x: x.hour * 60 + x.minute)
df["Delivery Time"] = pd.to_datetime(df["Delivery Time"], format="%H:%M:%S", errors="coerce") \
                      .apply(lambda x: x.hour * 60 + x.minute if pd.notnull(x) else np.nan)

from sklearn.linear_model import LinearRegression





# Select relevant features and target variable
features = ["Order Time", "Preparation Time (mins)", "Token Number", "Quantity"]
target = "Delivery Time"

X = df[features]
y = df[target]



X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Drop NaN values in y_train
X_train = X_train[~y_train.isna()]
y_train = y_train.dropna()

model = LinearRegression()
model.fit(X_train, y_train)

# Predict on test data
y_pred = model.predict(X_test)
#df["Predicted Delivery Time"] = [f"{int(m // 60):02}:{int(m % 60):02}:00" for m in y_pred]


# Evaluate the model
# Drop NaN values in y_test and y_pred before calculating metrics
y_test_filtered = y_test[~np.isnan(y_test) & ~np.isnan(y_pred)]
y_pred_filtered = y_pred[~np.isnan(y_test) & ~np.isnan(y_pred)]


mae = mean_absolute_error(y_test_filtered, y_pred_filtered)
mse = mean_squared_error(y_test_filtered, y_pred_filtered)

rmse = np.sqrt(mse)
print(f"MAE: {mae}, RMSE: {rmse}")

# Scatter plot of actual vs. predicted values
plt.figure(figsize=(8,6))
plt.scatter(y_test, y_pred, alpha=0.6, color="blue", label="Predicted vs. Actual")
plt.plot(y_test, y_test, color="red", linestyle="dashed", label="Perfect Fit Line")

# Labels and title
plt.xlabel("Actual Delivery Time (minutes)")
plt.ylabel("Predicted Delivery Time (minutes)")
plt.title("Actual vs. Predicted Delivery Time")
plt.legend()
plt.grid(True)
plt.show()







# prompt: queue management system

import queue

class QueueManagementSystem:
    def __init__(self):
        self.order_queue = queue.Queue()
        self.order_details = {}  # Store order details with order ID as key

    def add_order(self, order_id, customer_name, items):
        self.order_queue.put(order_id)
        self.order_details[order_id] = {
            "customer_name": customer_name,
            "items": items,
            "status": "Pending"
        }
        print(f"Order {order_id} added to the queue.")

    def process_next_order(self):
        if not self.order_queue.empty():
            order_id = self.order_queue.get()
            self.order_details[order_id]["status"] = "In Progress"
            print(f"Processing order {order_id} for {self.order_details[order_id]['customer_name']}.")
            # Simulate order processing time
            # ... your order preparation logic here ...
            self.complete_order(order_id)
        else:
            print("No orders in the queue.")

    def complete_order(self, order_id):
        if order_id in self.order_details:
            self.order_details[order_id]["status"] = "Completed"
            print(f"Order {order_id} completed.")
        else:
            print(f"Order {order_id} not found.")

    def get_order_status(self, order_id):
        if order_id in self.order_details:
            print(f"Order {order_id} status: {self.order_details[order_id]['status']}")
        else:
            print(f"Order {order_id} not found.")

# Example usage:
qms = QueueManagementSystem()

qms.add_order(1, "Alice", ["Burger", "Fries"])
qms.add_order(2, "Bob", ["Pizza"])
qms.add_order(3, "Charlie", ["Pasta", "Salad"])

qms.process_next_order()
qms.get_order_status(1)

qms.process_next_order()
qms.get_order_status(2)

qms.process_next_order()
qms.get_order_status(3)

qms.process_next_order() # Test when queue is empty
import joblib
joblib.dump(model, "model.pkl")
loaded_model = joblib.load("model.pkl")
prediction = loaded_model.predict(X[:5])
def convert_to_hms(minutes):
    if np.isnan(minutes):  # Handle NaN values
        return "NaN"
    hours = int(minutes // 60)
    mins = int(minutes % 60)
    return f"{hours:02}:{mins:02}:00"

# Apply conversion function
predicted_times = [convert_to_hms(m) for m in prediction]

# Display results
for i, time in enumerate(predicted_times):
    print(f"Order {i+1}: Predicted Delivery Time = {time}")